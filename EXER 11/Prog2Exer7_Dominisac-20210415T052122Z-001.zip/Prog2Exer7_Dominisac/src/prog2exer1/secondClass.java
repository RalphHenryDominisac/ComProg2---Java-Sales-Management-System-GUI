/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2exer1;

import com.sun.corba.se.impl.ior.NewObjectKeyTemplateBase;
import javax.swing.JTextField;

/**
 *
 * @author RALPH
 */
public class secondClass {
    
     
            /*
      
    public String[] Lists() {
        
        String[] z = new String[3];
        z[0] = "a";
        z[1] = "b";
        z[2] = "c";
        
        return z;
        
        //  String recieved = newObj.productDesc;
       // Products.Othermethod();
                
          // String[] itemTable1 = {pid.getText(), ptype.getText(), pdesc.getText(), supplier.getText(), "*0", "0"};
      //  Products newObj = new Products();
        
      //  String[] z = newObj.getAllValues();
        
        
        
    }
    
    public String[] ListsWithParameter(String[] x){
        String[] a = new String[3];
        a[0] = x[0];
        a[1] = x[1];
        a[2] = x[2];
        
        return a;
    }
    public void showList(){
       String[] b = ListsWithParameter(Lists()); 
        for(int x = 0; x < b.length; x++){
            System.out.println(b[x]);
        }
    }
    
    
    
    */
}
